let jugarDeNuevo = "SI";

while (jugarDeNuevo.toUpperCase() === "SI") {
    // 1. Generar número al azar entre 1 y 9
    let numComputadora = Math.floor(Math.random() * 9) + 1;
    let numUsuario;

    // 2. Pedir número y validar (rango 1 a 9)
    do {
        numUsuario = parseInt(prompt("Ingrese un número entre 1 y 9:"));
        if (numUsuario < 1 || numUsuario > 9 || isNaN(numUsuario)) {
            alert("Error: El número debe estar entre 1 y 9.");
        }
    } while (numUsuario < 1 || numUsuario > 9 || isNaN(numUsuario));

    // 3. Pedir la adivinanza
    let prediccion = prompt("¿Cree que su número es MAYOR, MENOR o IGUAL al de la computadora?").toUpperCase();
    let resultadoReal = "";

    // Determinar la relación real
    if (numUsuario > numComputadora) {
        resultadoReal = "MAYOR";
    } else if (numUsuario < numComputadora) {
        resultadoReal = "MENOR";
    } else {
        resultadoReal = "IGUAL";
    }

    // 4. Mostrar resultados y verificar si adivinó
    let mensaje = `La computadora eligió ${numComputadora}, usted eligió ${numUsuario}. `;
    
    if (prediccion === resultadoReal) {
        alert(mensaje + `Su elección es ${resultadoReal.toLowerCase()}. ¡Ha adivinado!`);
    } else {
        alert(mensaje + `Su elección fue ${prediccion.toLowerCase()}, pero era ${resultadoReal.toLowerCase()}. No ha adivinado.`);
    }

    // 5. Preguntar si quiere seguir
    jugarDeNuevo = prompt("¿Quiere jugar otra vez? (SI/NO)");
}

// Mensaje final al elegir NO
alert("Programa finalizado. Alumno: [Tu Nombre] - Carnet: [Tu Carnet]");